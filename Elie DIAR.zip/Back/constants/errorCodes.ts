export const WEATHER_API_ERROR = 2000;
export const DATABASE_ERROR = 2001;
export const UNKNOWN_ERROR = 9999;