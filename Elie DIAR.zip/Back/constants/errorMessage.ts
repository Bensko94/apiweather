export const WEATHER_API_ERROR_MESSAGE = "Erreur lors de la récupération des données météo";
export const UNKNOWN_ERROR_MESSAGE = "Une erreur inattendue s'est produite";