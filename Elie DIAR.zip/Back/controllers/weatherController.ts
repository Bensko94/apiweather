import {NextFunction, Request, Response } from "express";
import axios, {AxiosResponse} from "axios";
import { WEATHER_API_ERROR_MESSAGE } from "../constants/errorMessage";
import { WEATHER_API_URL } from "../constants/config";
import { ApiError } from "../errors/ApiError";
import { MinimalWeatherData } from "../interfaces/MinimalWeatherData";

/**
 * @swagger
 * tags:
 *  name: Weather
 *  description: Operations liés à  la météo
 */


export class WeatherController {
  private API_KEY: string;
  constructor(apiKey: string){
    this.API_KEY = apiKey;
  }

/**
   * @swagger
   * /weather/{city}:
   *   get:
   *     summary: Obtient les informations météo.
   *     description: Récupère les informations météo pour une ville donnée.
   *     tags: [Weather]
   *     parameters:
   *       - in: path
   *         name: city
   *         required: true
   *         description: Nom de la ville.
   *         schema:
   *           type: string
   *     responses:
   *       200:
   *         description: Succès. Retourne les données météo.
   *       400:
   *         description: Requête incorrecte. Vérifiez les paramètres.
   */

  public async getWeather(req: Request, res: Response, next: NextFunction): Promise<void>{
    const city: string = req.params.city;
    try{
      const response: AxiosResponse = await axios.get(
        `${WEATHER_API_URL}current.json?key=${this.API_KEY}&q=${city}&lang=fr`
      );
      
     const minimalData: MinimalWeatherData = {
        city: response.data.location.name,
        country: response.data.location.country,
        temperature: response.data.current.temp_c,
        condition: response.data.current.condition.text,
        icon: response.data.current.condition.icon
     }
     res.json(minimalData);
    }catch(error){
     next(new ApiError(WEATHER_API_ERROR_MESSAGE ))
    }
  }
    public async getLocation(req: Request, res: Response, next: NextFunction): Promise<void> {
    const city: string = req.params.city;
  
    try {
      const response: AxiosResponse = await axios.get(
        `${WEATHER_API_URL}current.json?key=${this.API_KEY}&q=${city}&lang=fr`
      );
  
      const responseData = response.data;
  
      
      if (responseData && responseData.location) {
        const locationData = {
          name: responseData.location.name,
          region: responseData.location.region,
          country: responseData.location.country,
          lat: responseData.location.lat,
          lon: responseData.location.lon,
          tz_id: responseData.location.tz_id,
          localtime_epoch: responseData.location.localtime_epoch,
          localtime: responseData.location.localtime
        };
  
        res.json(locationData);
      } else {
        
        throw new Error('');
      }
    } catch (error) {
      
      if (axios.isAxiosError(error)) {
       
        next(new ApiError(WEATHER_API_ERROR_MESSAGE ));
      } else {
       
        next(new ApiError(WEATHER_API_ERROR_MESSAGE ));
      }

    }
  }
}
