interface MinimalWeatherData {
  city: string;
  country: string;
  temperature: number;
  condition: string;
  icon: string;
}

export { MinimalWeatherData }